package com.sjkorea.meetagain.HomeFragment


import android.animation.ValueAnimator
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.sjkorea.meetagain.*
import com.sjkorea.meetagain.CustomZoomClass.CenterZoomLayout
import com.sjkorea.meetagain.UserFragment.HistoryFragment
import com.sjkorea.meetagain.UserFragment.UserFragment
import kotlinx.android.synthetic.main.fregment_home.view.*
import kotlinx.android.synthetic.main.main_item.*
import kotlinx.android.synthetic.main.main_item.view.*


class HomeFragment : Fragment() {
    var firestore: FirebaseFirestore? = null
    var user: FirebaseAuth? = null
    var uid: String? = null
    var fcmPush: FcmPush? = null
    var imagesSnapshot: ListenerRegistration? = null
    var imagesSnapshotmod :ListenerRegistration? = null

    private val customDialog = CustomBottomDialog()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {


        var homeview = inflater.inflate(R.layout.fregment_home, container, false)

//        var homeview =
//            LayoutInflater.from(activity).inflate(R.layout.fregment_home, container, false)
        firestore = FirebaseFirestore.getInstance()
        user = FirebaseAuth.getInstance()
        fcmPush = FcmPush()
        uid = arguments?.getString("destinationUid")
        Log.d(this.uid, "uid 1 ")

        val toursRV = homeview!!.findViewById<RecyclerView>(R.id.homefragment_recyclerview)

        homeview!!.homefragment_recyclerview.adapter = DetailViewRecyclerViewAdapter()
        homeview!!.homefragment_recyclerview.layoutManager = LinearLayoutManager(activity)

        val layoutManager = CenterZoomLayout(requireActivity())
        toursRV!!.isNestedScrollingEnabled = false
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        layoutManager.reverseLayout = true
        layoutManager.stackFromEnd = true
        toursRV!!.layoutManager = layoutManager

        return homeview
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        // .setOnClickListener {
        //     customDialog.show(childFragmentManager, "")
        // }
    }

    override fun onResume() {
        super.onResume()



    }

    override fun onStop() {
        super.onStop()
        imagesSnapshot?.remove()
    }



    inner class DetailViewRecyclerViewAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        val contentDTOs: ArrayList<ContentDTO>
        val contentUidList: ArrayList<String>

        var inflater = layoutInflater


        init {

            //아이디
            var uid = FirebaseAuth.getInstance().currentUser?.uid
            contentDTOs = java.util.ArrayList()
            contentUidList = java.util.ArrayList()

             imagesSnapshot = firestore?.collection("images")?.orderBy("timestamp")
                ?.addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                    contentDTOs.clear()
                    contentUidList.clear()
                    for (snapshot in querySnapshot!!.documents) {
                        var item = snapshot.toObject(ContentDTO::class.java)
                        contentDTOs.add(item!!)
                        contentUidList.add(snapshot.id)
                    }
                    notifyDataSetChanged()
                }
        }


        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

            var view =
                LayoutInflater.from(parent.context).inflate(R.layout.main_item, parent, false)





            return CustomViewHolder(view)
        }


        inner class CustomViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)


        override fun getItemCount(): Int {
            return contentDTOs.size
        }


        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            var viewholder = (holder as CustomViewHolder).itemView




            // Profile Image 가져오기

                firestore?.collection("profileImages")?.document(contentDTOs[position].uid!!)
                ?.get()?.addOnCompleteListener { task ->
                    if (task.isSuccessful) {

                        val url = task.result!!["image"]
                        Glide.with(holder.itemView.context)
                            .load(url)
                            .apply(RequestOptions().circleCrop())
                            .into(viewholder.homeviewitem_profile_image)

                    }
                }


            //UserFragment로 이동
            //   viewholder.homeviewitem_profile_image.setOnClickListener {
            //
            //      val bundle = Bundle()
            //      var fragment = CustomBottomDialog()
//
            //        bundle.putString("destinationUid", contentDTOs[position].uid)
            //       bundle.putString("userId", contentDTOs[position].userId)
//
            //        fragment.arguments = bundle
            //       activity!!.supportFragmentManager.beginTransaction()
            //              .replace(R.id.main_content, fragment)
            //             .commit()
            //     }
            //누르면 홈포스트 프래그먼트 호출
            viewholder.home_post_item.setOnClickListener {

                //번들 데이터
                val bundle = Bundle()
                var homePostfrg = HomePostFragment()


                //uid
                bundle.putString("destinationUid", contentDTOs[position].uid)
                Log.d(this.contentDTOs[position].uid, "홈 포스트 로그 uid 보내기 ")

                //userid
                bundle.putString("userId", contentDTOs[position].userId)
                Log.d(this.contentDTOs[position].userId, "홈 포스트 로그 userId 보내기 ")

                //title
                bundle.putString("title", contentDTOs[position].title)
                Log.d(this.contentDTOs[position].title, "홈 포스트 로그 title 보내기 ")

                //explain
                bundle.putString("explain", contentDTOs[position].explain)
                Log.d(this.contentDTOs[position].explain, "홈 포스트 로그 explain 보내기 ")

                //imageUrl
                bundle.putString("imageUrl", contentDTOs[position].imageUrl)
                Log.d(this.contentDTOs[position].imageUrl, "홈 포스트 로그 imageUrl 보내기 ")

                //favoriteCount
                bundle.putInt("favoriteCount", contentDTOs[position].favoriteCount)
                Log.d(
                    this.contentDTOs[position].favoriteCount.toString(),
                    "홈 포스트 로그 contentDTOs[position].favoriteCount.toString() 보내기 "
                )

                //userIdposition
                bundle.putString("userIdposition", contentUidList[position])
                Log.d(this.contentDTOs[position].toString(), "홈 포스트 로그 userIdposition 포지션 보내기 ")

                //meaningCount
                bundle.putInt("meaningCount", contentDTOs[position].meaningCount)
                Log.d(
                    this.contentDTOs[position].meaningCount.toString(),
                    "홈 포스트 로그 contentDTOs[position].favoriteCount.toString() 보내기 "
                )


                //좋아요버튼
                var hashmap = contentDTOs[position].favorites

                bundle.putSerializable("favoriteshashmap", hashmap)
                //싫어요버튼
                var hashmap2 = contentDTOs[position].meaning

                bundle.putSerializable("meaninghashmap", hashmap2)


//                bundle.putSerializable("hashmap", contentDTOs[position].favorites)

//                contentDTOs[position].favorites =
//                    bundle.getSerializable("hashmap") as HashMap<String, Boolean>
//
//
//                Log.d(
//                    this.contentDTOs[position].meaningCount.toString(),
//                    "홈 포스트 로그 contentDTOs[position].favoriteCount.toString() 보내기 ")


                homePostfrg.arguments = bundle
                requireActivity().supportFragmentManager.beginTransaction().replace(
                    R.id.main_content,
                    homePostfrg,

                    ).commit()
            }
            //제목
            viewholder.homeviewitem_profile_textview.text = contentDTOs[position].title


            // Image
            Glide.with(holder.itemView.context).load(contentDTOs[position].imageUrl)
                .into(viewholder.homeviewitem_imageview_content)


            // Explain
            viewholder.homeviewitem_explain_textview.text = contentDTOs!![position].explain

            // User Id
            viewholder.homeviewitem_profile_name.text = contentDTOs!![position].userId

            //프로필 다이얼로그
            viewholder.homeviewitem_profile_image.setOnClickListener {

//                val fragment = CustomBottomDialog()
//                val bundle = Bundle()
//                bundle.putString("destinationUid", contentDTOs[position].uid)
//                fragment.arguments = bundle
//                customDialog.show(childFragmentManager, "")
//
//                val bundle = Bundle()
//                    for (entry in data.entries) bundle.putString(entry.key, entry.value)

//
                //프로필 데이터 커스텀 바텀 다이로그로 보내기
                val bundle = Bundle()

                bundle.putString("destinationUid", contentDTOs[position].uid)
                bundle.putString("userId", contentDTOs[position].userId)


                val userFragment = UserFragment()
                val customDialog: DialogFragment = CustomBottomDialog()
                val historyF = HistoryFragment()


                userFragment.arguments = bundle
                customDialog.arguments = bundle
                historyF.arguments = bundle
                customDialog.show(activity?.supportFragmentManager!!, "")

//
//                val bundlet = Bundle()
//                bundlet.putString("title",contentDTOs[position].uid)
//                Log.d(contentDTOs[position].uid.toString(), "로그 홈 타이틀 ")
//                historyF.arguments = bundle

            }


//            viewholder.homeviewitem_profile_image.setOnClickListener {
//                Log.d("clickTest", "아이템 클릭 확인. position : ${holder.adapterPosition}")
//
//            }


//                viewholder.title_text.setOnClickListener {
//
////                val fragment = CustomBottomDialog()
////                val bundle = Bundle()
////                bundle.putString("destinationUid", contentDTOs[position].uid)
////                fragment.arguments = bundle
////                customDialog.show(childFragmentManager, "")
////
////                val bundle = Bundle()
////                    for (entry in data.entries) bundle.putString(entry.key, entry.value)
////
//                val fragment = UserFragment()
//                val bundle = Bundle()
//
//                bundle.putString("destinationUid", contentDTOs[position].uid)
//                bundle.putString("userId", contentDTOs[position].userId)
//
//                fragment.arguments = bundle
//                activity!!.supportFragmentManager.beginTransaction()
//                    .replace(R.id.main_content, fragment)
//                    .commit()

//            }


            // likes
            viewholder.homeviewitem_favoritecounter_textview.text =
                "좋아요" + contentDTOs!![position].favoriteCount + "개"

            viewholder.homeviewitem_fovorite_imageview.setOnClickListener {
                favoriteEvent(position)
            }


            //좋아요 버튼 설정


            if (contentDTOs[position].favorites.containsKey(FirebaseAuth.getInstance().currentUser!!.uid)) {

//                val animator = ValueAnimator.ofFloat(0f, 0.5f).setDuration(1000)
//
//                animator.addUpdateListener { animation: ValueAnimator ->
//                    viewholder.homeviewitem_fovorite_imageview.setProgress(
//                        animation.getAnimatedValue() as Float
//                    )
//
//                }
//                animator.start()
//                isLiked = true


                viewholder.homeviewitem_fovorite_imageview.setImageResource(R.drawable.heart_redc)

            } else {
                viewholder.homeviewitem_fovorite_imageview.setImageResource(R.drawable.heart_red)


//                val animator = ValueAnimator.ofFloat(0.5f, 0.9f).setDuration(1000)
//
//
//                animator.addUpdateListener { animation: ValueAnimator ->
//                    viewholder.homeviewitem_fovorite_imageview.setProgress(
//                        animation.getAnimatedValue() as Float
//                    )
//
//                }
//                animator.start()
            }


            // meaning
            viewholder.homeviewitem_meaningcounter_textview.text =
                "슬퍼요" + contentDTOs!![position].meaningCount + "개"
            viewholder.homeviewitem_meaning_imageview.setOnClickListener {
                meaningEvent(position)
            }
            //슬퍼요 버튼 설정
            if (contentDTOs[position].meaning.containsKey(FirebaseAuth.getInstance().currentUser!!.uid)) {

                viewholder.homeviewitem_meaning_imageview.setImageResource(R.drawable.heart_bluec)

            } else {

                viewholder.homeviewitem_meaning_imageview.setImageResource(R.drawable.heart_blue)
            }

//            //comentSize
//            viewholder.homeviewitem_commentcounter_textview.text = "댓글" + comments.size


        }

        fun favoriteEvent(position: Int) {
            var tsDoc = firestore?.collection("images")?.document(contentUidList[position])


            contentUidList[position]
            firestore?.runTransaction { transaction ->
                var uid = FirebaseAuth.getInstance().currentUser!!.uid
                var contentDTO = transaction.get(tsDoc!!).toObject(ContentDTO::class.java)

                if (contentDTO!!.favorites.containsKey(uid)) {
                    // When the button is clicked
                    contentDTO.favoriteCount = contentDTO?.favoriteCount - 1
                    contentDTO.favorites.remove(uid)
                } else {
                    // When the button is not clicked
                    contentDTO.favoriteCount = contentDTO?.favoriteCount + 1
                    contentDTO.favorites[uid!!] = true
                    favoriteAlarm(contentDTOs[position].uid!!)
                }
                transaction.set(tsDoc, contentDTO)
            }
        }

        fun meaningEvent(position: Int) {
            var tsDoc = firestore?.collection("images")?.document(contentUidList[position])


            firestore?.runTransaction { transaction ->

                var contentDTO = transaction.get(tsDoc!!).toObject(ContentDTO::class.java)
                var uid = FirebaseAuth.getInstance().currentUser!!.uid

                if (contentDTO!!.meaning.containsKey(uid)) {

                    // When the button is clicked
                    contentDTO.meaningCount = contentDTO?.meaningCount - 1
                    contentDTO.meaning.remove(uid)
                } else {

                    // When the button is not clicked
                    contentDTO.meaningCount = contentDTO?.meaningCount + 1
                    contentDTO.meaning[uid!!] = true

                    meaningAlarm(contentDTOs[position].uid!!)
                }
                transaction.set(tsDoc, contentDTO)
            }

        }

        fun favoriteAlarm(destinationUid: String) {
            var alarmDTO = AlarmDTO()
            alarmDTO.destinationUid = destinationUid
            alarmDTO.userId = user?.currentUser?.email
            alarmDTO.uid = user?.currentUser?.uid
            alarmDTO.kind = 0
            alarmDTO.timestamp = System.currentTimeMillis()

            FirebaseFirestore.getInstance().collection("alarms").document().set(alarmDTO)

            var message = user?.currentUser?.email + getString(R.string.alarm_favorite)
            fcmPush?.sendMessage(destinationUid,"알림 메시지 입니다",message)
        }

        fun meaningAlarm(destinationUid: String) {
            var alarmDTO = AlarmDTO()
            alarmDTO.destinationUid = destinationUid
            alarmDTO.userId = user?.currentUser?.email
            alarmDTO.uid = user?.currentUser?.uid
            alarmDTO.kind = 3
            alarmDTO.timestamp = System.currentTimeMillis()

            FirebaseFirestore.getInstance().collection("alarms").document().set(alarmDTO)

            var message = user?.currentUser?.email + "님이 힘내요를 눌렀습니다"
            fcmPush?.sendMessage(destinationUid,"알림 메시지 입니다",message)
        }
    }
}







