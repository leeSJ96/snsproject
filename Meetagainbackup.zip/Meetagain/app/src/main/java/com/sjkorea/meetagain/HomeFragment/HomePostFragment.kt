package com.sjkorea.meetagain.HomeFragment

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.sjkorea.meetagain.Comment.CommentFragment
import com.sjkorea.meetagain.ContentDTO
import com.sjkorea.meetagain.CustomBottomDialog
import com.sjkorea.meetagain.R
import com.sjkorea.meetagain.UserFragment.HistoryFragment
import com.sjkorea.meetagain.UserFragment.UserFragment
import kotlinx.android.synthetic.main.custom_dialog.*
import kotlinx.android.synthetic.main.custom_dialog.view.*
import kotlinx.android.synthetic.main.fregment_home.view.*
import kotlinx.android.synthetic.main.fregment_home_post.*
import kotlinx.android.synthetic.main.fregment_home_post.view.*
import kotlinx.android.synthetic.main.main_item.view.*

class HomePostFragment : Fragment() {
    var firestore: FirebaseFirestore? = null
    var user: FirebaseUser? = null
    var imagesSnapshot: ListenerRegistration? = null
    val manager = LinearLayoutManager(activity)
    var uid: String? = null
    var homepostview: View? = null
    var uidsize : Int? = null
    var userId: String? = null
    var title: String? = null
    var explain: String? = null
    var imageUrl: String? = null
    var favoriteCount: Int? = null
    var meaningCount: Int? = null
    var favorites: HashMap<String, Boolean> = HashMap()
    var favoritess: String? = null
    var meaning: HashMap<String, Boolean> = HashMap()
    var contentUidListposition: String? = null


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        var homepostview = inflater.inflate(R.layout.fregment_home_post, container, false)


//        var homeview =
//            LayoutInflater.from(activity).inflate(R.layout.fregment_home, container, false)
        firestore = FirebaseFirestore.getInstance()

        userId = requireArguments().getString("userId")
        Log.d(this.userId, "홈 포스트 로그 userId 받기 ")


        uid = arguments?.getString("destinationUid")
        Log.d(this.uid, "홈 포스트 로그 uid 받기 ")

        uidsize = arguments?.getInt("uidsize")
        Log.d(this.uid, "홈 포스트 로그 uid 받기 ")


        title =  requireArguments().getString("title")
        Log.d(this.title, "홈 포스트 로그 title 받기 ")

        explain =  requireArguments().getString("explain")
        Log.d(this.explain, "홈 포스트 로그 explain 받기 ")

        imageUrl =  requireArguments().getString("imageUrl")
        Log.d(this.imageUrl, "홈 포스트 로그 imageUrl 받기 ")

        favoriteCount =  requireArguments().getInt("favoriteCount")
        Log.d(this.favoriteCount.toString(), "홈 포스트 로그 favoriteCount 받기 ")

        meaningCount =  requireArguments().getInt("meaningCount")
        Log.d(this.meaningCount.toString(), "홈 포스트 로그 meaningCount 받기 ")

        favorites  = requireArguments().getSerializable("favoriteshashmap") as HashMap<String, Boolean>
        Log.d(this.favorites.toString(), "홈 포스트 로그 favorites 받기 ")

        meaning  = requireArguments().getSerializable("meaninghashmap") as HashMap<String, Boolean>
        Log.d(this.meaning.toString(), "홈 포스트 로그 favorites 받기 ")

        contentUidListposition = requireArguments().getString("userIdposition")
        Log.d(contentUidListposition.toString(), " 홈 포스트 로그 contentUidListposition 받기")

        val contentDTOs: ArrayList<ContentDTO>
        val contentUidList: ArrayList<String>
        contentDTOs = java.util.ArrayList()
        contentUidList = java.util.ArrayList()

        //댓글창
        homepostview.bottomviewitem_comment_imageview.setOnClickListener {

            val customcommentDialog = CommentFragment()
            var bundle = Bundle()

            bundle.putString("contentUid", contentUidListposition)
            bundle.putString("destinationUid",uid)

            Log.d(contentUidListposition, "코멘트 로그 보내기 ")

            customcommentDialog
            customcommentDialog.arguments = bundle
            customcommentDialog.show(activity?.supportFragmentManager!!, "")
        }


        //좋아요 버튼 설정
        if (favorites.containsKey(FirebaseAuth.getInstance().currentUser!!.uid)) {

            homepostview.home_post_favorite_imageview.setImageResource(R.drawable.heart_redc)

        } else {

            homepostview.home_post_favorite_imageview.setImageResource(R.drawable.heart_red)
        }

        //슬퍼요 버튼 설정
        if (meaning.containsKey(FirebaseAuth.getInstance().currentUser!!.uid)) {

            homepostview.home_post_ma_imageview.setImageResource(R.drawable.heart_bluec)

        } else {

            homepostview.home_post_ma_imageview.setImageResource(R.drawable.heart_blue)
        }


//        // meaning
//        homepostview.homeviewitem_meaningcounter_textview.text =
//            "슬퍼요" + contentDTOs!![position].meaningCount + "개"
//        homepostview.homeviewitem_meaning_imageview.setOnClickListener {
//            meaningEvent(position)
//        }
//        //슬퍼요 버튼 설정
//        if (contentDTOs[position].meaning.containsKey(FirebaseAuth.getInstance().currentUser!!.uid)) {
//
//            homepostview.homeviewitem_meaning_imageview.setImageResource(R.drawable.m2)
//
//        } else {
//
//            homepostview.homeviewitem_meaning_imageview.setImageResource(R.drawable.m1)
//        }

        gethomeposttitle()
        getProfileImage()

//        homepostview.home_post_favorite_imageview.setOnClickListener {
//            favoriteEvent()
//            Log.d(favoriteEvent().toString(), " 로그")
//        }

        return homepostview
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        // .setOnClickListener {
        //     customDialog.show(childFragmentManager, "")
        // }





    }


//
//    //좋아요 이벤트 기능
//    private fun favoriteEvent(position: Int) {
//
//        val contentUidList: ArrayList<String>
//        contentUidList = java.util.ArrayList()
//
//        var tsDoc = firestore?.collection("images")?.document(contentUidList[position])
//        firestore?.runTransaction { transaction ->
//
//            val uid = FirebaseAuth.getInstance().currentUser!!.uid
//            val contentDTO = transaction.get(tsDoc!!).toObject(ContentDTO::class.java)
//
//            if (contentDTO!!.favorites.containsKey(uid)) {
//                // Unstar the post and remove self from stars
//                contentDTO?.favoriteCount = contentDTO?.favoriteCount!! - 1
//                contentDTO?.favorites.remove(uid)
//
//            } else {
//                // Star the post and add self to stars
//                contentDTO?.favoriteCount = contentDTO?.favoriteCount!! + 1
//                contentDTO?.favorites[uid] = true
//            }
//            transaction.set(tsDoc, contentDTO)
//        }
//    }
//
//    //싫어요
//    fun meaningEvent(position: Int) {
//        var tsDoc = firestore?.collection("images")?.document(contentUidList[position])
//
//
//        firestore?.runTransaction { transaction ->
//
//            var contentDTO = transaction.get(tsDoc!!).toObject(ContentDTO::class.java)
//            var uid = FirebaseAuth.getInstance().currentUser!!.uid
//
//            if (contentDTO!!.meaning.containsKey(uid)) {
//                // When the button is clicked
//                contentDTO.meaningCount = contentDTO?.meaningCount - 1
//                contentDTO.meaning.remove(uid)
//            } else {
//                // When the button is not clicked
//                contentDTO.meaningCount = contentDTO?.meaningCount + 1
//                contentDTO.meaning[uid!!] = true
//            }
//            transaction.set(tsDoc, contentDTO)
//        }
//    }
    fun getProfileImage() {

    val contentDTOs: ArrayList<ContentDTO>
    contentDTOs = java.util.ArrayList()

        firestore?.collection("profileImages")?.document(uid!!)
            ?.addSnapshotListener { documentSnapshot, firebaseFirestoreException ->
                if (documentSnapshot == null) return@addSnapshotListener
                if (documentSnapshot.data != null) {
                    val url = documentSnapshot.data!!["image"]
                    Glide.with(this).load(url).apply(RequestOptions().circleCrop())
                        .into(this.home_post_profile_image)



                }
            }
    }

    fun gethomeposttitle() {
        var contentDTO: ArrayList<ContentDTO>
        contentDTO = ArrayList()

        firestore?.collection("images")?.whereEqualTo("uid", uid)
            ?.addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                contentDTO.clear()
                if (querySnapshot == null)
                    return@addSnapshotListener
                for (snapshot in querySnapshot!!.documents) {
                    Log.d(ContentValues.TAG, "1")
                    contentDTO.add(snapshot.toObject(ContentDTO::class.java)!!)
                    Log.d(ContentValues.TAG, "2")
//                    bottom_tv_post_count.text = contentDTO.size.toString()

                    //프로필 사진
                    home_post_profile_textview.text = userId.toString()
                    // 제목 텍스트
                    home_post_title_textview.text = title.toString()
                    // 내용 텍스트
                    home_post_explain_textview.text = explain.toString()
                    // 이미지 사진
                    Glide.with(this).load(imageUrl)
                        .into(home_post_imageview_content)
                    //좋아요개수
                    home_post_like.text =
                        "좋아요" + favoriteCount.toString() + "개"
                    //싫어요개수
                    home_post_ma.text =
                        "싫어요" + meaningCount.toString() + "개"

                    //좋아요 버튼 설정
                    if (favorites.containsKey(FirebaseAuth.getInstance().currentUser!!.uid)) {

                        homepostview?.home_post_favorite_imageview?.setImageResource(R.drawable.heart_redc)

                    } else {

                        homepostview?.home_post_favorite_imageview?.setImageResource(R.drawable.heart_red)
                    }

                    //슬퍼요 버튼 설정
                    if (meaning.containsKey(FirebaseAuth.getInstance().currentUser!!.uid)) {

                        homepostview?.home_post_ma_imageview?.setImageResource(R.drawable.heart_bluec)

                    } else {

                        homepostview?.home_post_ma_imageview?.setImageResource(R.drawable.heart_blue)
                    }







                    Log.d(contentDTO.size.toString(), "bottomsize테스트")
                }

            }

    }

//    fun favoriteEvent(){
//        var tsDoc = firestore?.collection("images")?.document(contentUidListposition!!)
//
//        firestore?.runTransaction { transaction ->
//
//            var contentDTO = transaction.get(tsDoc!!).toObject(ContentDTO::class.java)
//
//            if(contentDTO!!.favorites.containsKey(uid)){
//                // When the button is clicked
//                contentDTO.favoriteCount = contentDTO?.favoriteCount - 1
//                contentDTO.favorites.remove(uid)
//            }else{
//                // When the button is not clicked
//                contentDTO.favoriteCount = contentDTO?.favoriteCount + 1
//                contentDTO.favorites[uid!!] = true
//            }
//            transaction.set(tsDoc,contentDTO)
//        }
//    }



}








