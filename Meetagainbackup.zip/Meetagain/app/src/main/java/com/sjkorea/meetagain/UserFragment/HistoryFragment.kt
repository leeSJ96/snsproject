package com.sjkorea.meetagain.UserFragment

import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.sjkorea.meetagain.ContentDTO
import com.sjkorea.meetagain.MainActivity
import com.sjkorea.meetagain.R
import kotlinx.android.synthetic.main.custom_dialog.*
import kotlinx.android.synthetic.main.fregment_user.*
import kotlinx.android.synthetic.main.fregment_user.view.*
import kotlinx.android.synthetic.main.viewpager_history_item.view.*
import kotlin.math.log


class HistoryFragment : Fragment() {

    var historyview: View? = null
    // 내가 선택한 uid
    var uid: String? = null
    var auth: FirebaseAuth? = null
    var firestore: FirebaseFirestore? = null
    //현재 나의 uid
    var currentUserUid: String? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

//        currentUserUid = FirebaseAuth.getInstance().currentUser?.uid
        auth = FirebaseAuth.getInstance()
//        uid = requireArguments().getString("title")

        currentUserUid   = FirebaseAuth.getInstance().currentUser?.uid
//        uid = arguments?.getString("destinationUid")
        Log.d(uid.toString(), "로그 히스토리 받기 ")
//
//        Log.d(FirebaseAuth.getInstance().currentUser?.uid.toString(), "로그히스토리받기 ")
        firestore = FirebaseFirestore.getInstance()

        Log.d(this.uid,"d ")
        historyview = LayoutInflater.from(inflater.context).inflate(R.layout.viewpager_history_item,container,false)
        Log.d(TAG, "로그  히스토리 화면: ")
        var recyclerView = historyview?.findViewById<RecyclerView>(R.id.viewrv)
        Log.d(TAG, "로그  히스토리 버튼: ")
        recyclerView!!.viewrv.adapter = HistoryRecyclerviewAdapter()
        Log.d(TAG, "로그  히스토리 어뎁터")
        recyclerView.viewrv.layoutManager = GridLayoutManager(activity, 3)
        Log.d(TAG, "로그  히스토리 레이아웃매니저: ")


        return historyview
    }



    inner class HistoryRecyclerviewAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var contentDTO: ArrayList<ContentDTO>



        init {
            contentDTO = ArrayList()
            firestore?.collection("images")?.whereEqualTo("uid", currentUserUid)?.addSnapshotListener { querySnapshot, firebaseFirestoreException  ->

                contentDTO.clear()
                if (querySnapshot == null)
                    return@addSnapshotListener
                for (snapshot in querySnapshot.documents){
                    Log.d(TAG, "음 스냅샷: ")
                    contentDTO.add(snapshot.toObject(ContentDTO::class.java)!!)



                }
                notifyDataSetChanged()

//                 val userFragment = UserFragment()
//                 val bundle = Bundle()
//                 bundle.putInt("one", contentDTO.size)
//                 Log.d(TAG,"size 보내기 ")
//                 userFragment.arguments = bundle


                notifyDataSetChanged()

            }
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val width = resources.displayMetrics.widthPixels / 3
            val imageView = ImageView(parent.context)
            imageView.layoutParams = LinearLayoutCompat.LayoutParams(width, width)
            return CustomViewHolder(imageView)
        }

        inner class CustomViewHolder(var imageView: ImageView) : RecyclerView.ViewHolder(imageView)

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            var imageView = (holder as CustomViewHolder).imageView
            Glide.with(holder.itemView.context).load(contentDTO[position].imageUrl).apply(
                RequestOptions().centerCrop()
            ).into(imageView)



        }

        override fun getItemCount(): Int {
            return contentDTO.size
        }



    }




}