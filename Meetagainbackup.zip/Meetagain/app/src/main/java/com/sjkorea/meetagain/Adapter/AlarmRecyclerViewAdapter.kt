package com.sjkorea.meetagain.Adapter


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.sjkorea.meetagain.AlarmDTO
import com.sjkorea.meetagain.R
import io.grpc.internal.JsonUtil.getString
import kotlinx.android.synthetic.main.item_comment.view.*

class AlarmRecyclerViewAdapter(var alerview : View) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var alarmSnapshot : ListenerRegistration? = null
    var alarmDTOList: ArrayList<AlarmDTO> = arrayListOf()

    init {
        var uid = FirebaseAuth.getInstance().currentUser!!.uid

        alarmSnapshot = FirebaseFirestore.getInstance().collection("alarms").whereEqualTo("destinationUid", uid)
            .addSnapshotListener { querySnapshot, firebaseFirestoreException ->
                if (querySnapshot == null) return@addSnapshotListener
                alarmDTOList.clear()
                for (snapshot in querySnapshot.documents) {
                    alarmDTOList.add(snapshot.toObject(AlarmDTO::class.java)!!)
                }

                alarmDTOList.sortByDescending { it.timestamp }
                notifyDataSetChanged()
            }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_comment, parent, false)

        return CustomViewHolder(view)
    }

    inner class CustomViewHolder(view: View?) : RecyclerView.ViewHolder(view!!)

    override fun getItemCount(): Int {
        return alarmDTOList.size

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        val commentTextview = holder.itemView.commentviewitem_textview_profile
        val porfileImage = holder.itemView.commentviewitem_imageview_profile

        var view = holder.itemView

        FirebaseFirestore.getInstance().collection("profileImages")
            .document(alarmDTOList[position].uid!!).get().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val url = task.result!!["image"]
                    Glide.with(view.context).load(url).apply(RequestOptions().circleCrop())
                        .into(porfileImage)
                }
            }

        when (alarmDTOList[position].kind) {

            0 -> {
                val str_0 = alarmDTOList[position].userId + "님이 좋아요를 눌렀습니다."
                commentTextview.text = str_0
            }

            1 -> {
                val str_1 =
                    alarmDTOList[position].userId + " " + "님이 댓글을 남겼습니다.\n\n" + "댓글내용 : " + alarmDTOList[position].message
                commentTextview.text = str_1
            }

            2 -> {
                val str_2 =
                    alarmDTOList[position].userId + "님이 당신의 팬이 되었습니다."
                commentTextview.text = str_2
            }

            3 -> {
                val str_3 = alarmDTOList[position].userId + "님이 싫어요를 눌렀습니다."
                commentTextview.text = str_3

            }
        }
//        .commentviewitem_textview_comment.visibility = View.INVISIBLE

    }




}