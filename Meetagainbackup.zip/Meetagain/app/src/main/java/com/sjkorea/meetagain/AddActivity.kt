package com.sjkorea.meetagain

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.android.synthetic.main.activity_add.*
import java.text.SimpleDateFormat
import java.util.*


class AddActivity : AppCompatActivity() {

    val PICTURE_REQUEST_CODE = 100

    private var selectedUriList: List<Uri>? = null

    var auth: FirebaseAuth? = null
    var photoUri: Uri? = null
    var storage: FirebaseStorage? = null
    var firestore: FirebaseFirestore? = null
    var btnSelectImage: Button? = null




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)
        // add image upload event
        addphoto_btn_upload.setOnClickListener {
            contentUpload()
        }

        // Initiate storage
        auth= FirebaseAuth.getInstance()
        storage = FirebaseStorage.getInstance()
        firestore = FirebaseFirestore.getInstance()
        btnSelectImage = findViewById(R.id.btn_select_image)


//        btn_select_image?.setOnClickListener {
//            openBottomPicker()
//        }
        btn_select_image.setOnClickListener {

            val intent = Intent(Intent.ACTION_GET_CONTENT, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)
            //사진을 여러개 선택할수 있도록 한다
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            intent.type = "image/*"
            startActivityForResult(
                Intent.createChooser(intent, "Select Picture"),
                PICTURE_REQUEST_CODE
            )
        }


//        addphoto_btn_upload.setOnClickListener {
//            TedImagePicker.with(this)
//                //.mediaType(MediaType.IMAGE)
//                //.scrollIndicatorDateFormat("YYYYMMDD")
//                //.buttonGravity(ButtonGravity.BOTTOM)
//                //.buttonBackground(R.drawable.btn_sample_done_button)
//                //.buttonTextColor(R.color.sample_yellow)
//                .errorListener { message -> Log.d("ted", "message: $message") }
//                .selectedUri(selectedUriList)
//                .startMultiImage { list: List<Uri> -> showMultiImage(list) }
//        }



    }


//    private fun openBottomPicker() {
//        ImagePicker.with(this)
//            .crop()                    //Crop image(Optional), Check Customization for more option
//            .compress(1024)            //Final image size will be less than 1 MB(Optional)
//            .maxResultSize(
//                1080,
//                1080
//            )    //Final image resolution will be less than 1080 x 1080(Optional)
//            .start()
//
//    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICTURE_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {

                //기존 이미지 지우기
                Image_p1.setImageResource(0)
                Image_p2.setImageResource(0)
                Image_p3.setImageResource(0)

                //ClipData 또는 Uri를 가져온다
                 photoUri = data!!.data

               val  clipData = data.clipData

                //이미지 URI 를 이용하여 이미지뷰에 순서대로 세팅한다.
                if (clipData != null) {
                    for (i in 0..2) {
                        if (i < clipData.itemCount) {
                            val urione = clipData.getItemAt(i).uri
                            when (i) {
                                0 -> Image_p1.setImageURI(urione)
                                1 -> Image_p2.setImageURI(urione)
                                2 -> Image_p3.setImageURI(urione)
                            }
                        }
                    }
                } else if (photoUri != null) {
                    Image_p1.setImageURI(photoUri)
                }
            }
        }
    }

    fun contentUpload() {
        // Make filename
        var timestamp = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        var imageFileName = "IMAGE_" + timestamp + "_.png"



        // Callback method
        var storageRef = storage?.reference?.child("images")?.child(imageFileName)
        storageRef?.putFile(photoUri!!)?.addOnSuccessListener {
            Toast.makeText(this, getString(R.string.upload_success),Toast.LENGTH_LONG).show()
            storageRef.downloadUrl.addOnSuccessListener { uri ->
                var contentDTO = ContentDTO()

                // Insert downloadUrl of image
                contentDTO.imageUrl = uri.toString()

                // Insert uid of user
                contentDTO.uid = auth?.currentUser?.uid


                // Insert userId
                contentDTO.userId = auth?.currentUser?.email

                // Insert explain of content
                contentDTO.explain = addphoto_edit_explain.text.toString()

                contentDTO.title = addphoto_edit_mamo.text.toString()


                // Insert timestamp
                contentDTO.timestamp = System.currentTimeMillis()

                firestore?.collection("images")?.document()?.set(contentDTO)

                setResult(Activity.RESULT_OK)

                finish()
            }
        }

    }




//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        if (resultCode == Activity.RESULT_OK) {
//            //Image Uri will not be null for RESULT_OK
//            val fileUri = data?.data
//            Image_p1.setImageURI(fileUri)
//
//
//            //You can get File object from intent
//            val file: File = ImagePicker.getFile(data)!!
//
//            //You can also get File Path from intent
//            val filePath: String = ImagePicker.getFilePath(data)!!
//        } else if (resultCode == ImagePicker.RESULT_ERROR) {
//            Toast.makeText(this, ImagePicker.getError(data), Toast.LENGTH_SHORT).show()
//        } else {
//            Toast.makeText(this, "Task Cancelled", Toast.LENGTH_SHORT).show()
//        }
//    }


}
//    private fun showMultiImage(uriList: List<Uri>) {
//        this.selectedUriList = uriList
//        Log.d("ted", "uriList: $uriList")
//        binding.ivImage.visibility = View.GONE
//        binding.containerSelectedPhotos.visibility = View.VISIBLE
//
//        binding.containerSelectedPhotos.removeAllViews()

//        val viewSize =
//            TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 100f, resources.displayMetrics)
//                .toInt()
//        uriList.forEach {
//            val itemImageBinding = ItemImageBinding.inflate(LayoutInflater.from(this))
//            Glide.with(this)
//                .load(it)
//                .apply(RequestOptions().fitCenter())
//                .into(itemImageBinding.ivMedia)
//            itemImageBinding.root.layoutParams = FrameLayout.LayoutParams(viewSize, viewSize)
//            binding.containerSelectedPhotos.addView(itemImageBinding.root)
//        }


//
//        val permissionlistener: PermissionListener = object : PermissionListener {
//            override fun onPermissionGranted() {
//                Toast.makeText(this@AddActivity, "Permission Granted", Toast.LENGTH_SHORT).show()
//            }
//
//            override fun onPermissionDenied(deniedPermissions: List<String>) {
//                Toast.makeText(
//                    this@AddActivity,
//                    "Permission Denied\n$deniedPermissions",
//                    Toast.LENGTH_SHORT
//                )
//                    .show()
//            }
//        }
//        TedPermission.with(this)
//            .setPermissionListener(permissionlistener)
//            .setRationaleTitle(R.string.rationale_title)
//            .setRationaleMessage(R.string.rationale_message)
//            .setDeniedTitle("Permission denied")
//            .setDeniedMessage(
//                "If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]"
//            )
//            .setGotoSettingButtonText("bla bla")
//            .setPermissions(
//                Manifest.permission.WRITE_EXTERNAL_STORAGE,
//                Manifest.permission.ACCESS_FINE_LOCATION
//            )
//            .check()
//    }
//
//
//    private fun openBottomPicker() {
//
//
//        TedBottomPicker.with(this@AddActivity)
//
//            .setPeekHeight(1600)
//            .showTitle(false)
//            .setCompleteButtonText("Done")
//            .setEmptySelectionText("No Select")
//            .setSelectedUriList(selectedUriList)
//
//            .showMultiImage {
//            }
//
//
//    }
//
//
//}


//    private fun selectCamera() {
//        var permission = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
//        if (permission == PackageManager.PERMISSION_DENIED) { // 권한 없어서 요청
//            ActivityCompat.requestPermissions(
//                this,
//                arrayOf(Manifest.permission.CAMERA),
//                REQ_CAMERA_PERMISSION
//            )
//        } else { // 권한 있음
//            var state = Environment.getExternalStorageState()
//            if (TextUtils.equals(
//                    state,
//                    Environment.MEDIA_MOUNTED
//                )
//            ) {
//                var intent =
//                    Intent(MediaStore.ACTION_IMAGE_CAPTURE)
//                intent.resolveActivity(packageManager)?.let {
//                    var photoFile: File? = createImageFile()
//                    photoFile?.let {
//                        var photoUri = FileProvider.getUriForFile(
//                            this,
//                            BuildConfig.APPLICATION_ID + ".provider", it
//                        )
//                        intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
//                        startActivityForResult(intent, REQ_IMAGE_CAPTURE)
//                    }
//                }
//            }
//        }
//    }
//
//    private fun createImageFile(): File {
//        // 사진이 저장될 폴더 있는지 체크
//        var file = File(
//            Environment.getExternalStorageDirectory(),
//            "/path/"
//        )
//        if (!file.exists()) file.mkdir()
//        var imageName = "fileName.jpeg"
//
//        var imageFile = File(
//            "${Environment.getExternalStorageDirectory().absoluteFile}/path/",
//            "$imageName"
//        )
//        imagePath = imageFile.absolutePath
//        return imageFile
//    }
//
//
//    private fun selectGallery() {
//        var writePermission =
//            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
//        var readPermission =
//            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
//        if (writePermission == PackageManager.PERMISSION_DENIED || readPermission == PackageManager.PERMISSION_DENIED) {
//            // 권한 없어서 요청
//            ActivityCompat.requestPermissions(
//                this,
//                arrayOf(
//                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
//                    Manifest.permission.READ_EXTERNAL_STORAGE
//                ),
//                REQ_STORAGE_PERMISSION
//            )
//        } else {
//            // 권한 있음
//            var intent = Intent(Intent.ACTION_PICK)
//            intent.data = MediaStore.Images.Media.EXTERNAL_CONTENT_URI intent . type = "image/*"
//            startActivityForResult(intent, REQ_GALLERY)
//
//
//        }
//    }
//
//    private fun getRealPathFromURI(uri: Uri): String {
//        var buildName = Build.MANUFACTURER
//        if (buildName.equals("Xiaomi")) {
//            return uri.path
//        }
//        var columnIndex = 0
//        var proj = arrayOf(MediaStore.Images.Media.DATA)
//        var cursor = contentResolver.query(uri, proj, null, null, null)
//        if (cursor!!.moveToFirst()) {
//            columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
//        }
//        return cursor.getString(columnIndex)
//    }
//
//
//    private fun getResizePicture(imagePath: String): Bitmap {
//        var options = BitmapFactory.Options()
//        options . inJustDecodeBounds = true
//        BitmapFactory.decodeFile(imagePath, options)
//        var resize = 1000
//        var width = options.outWidth
//        var height = options.outHeight
//        var sampleSize = 1
//        while (true) {
//            if (width / 2 < resize || height / 2 < resize)
//                break
//            width /= 2
//            height /= 2
//            sampleSize *= 2
//
//        }
//        options . inSampleSize = sampleSize
//        options.inJustDecodeBounds = false
//        var resizeBitmap = BitmapFactory.decodeFile(imagePath, options) // 회전값 조정
//        var exit = ExifInterface(imagePath)
//        var exifDegree = 0
//        exit ?. let {
//            var exifOrientation =
//                it.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
//            exifDegree = exifOreintationToDegrees(exifOrientation)
//        }
//        return roteateBitmap(resizeBitmap, exifDegree)
//    }
//
//    private fun saveBitmap(bitmap: Bitmap): String {
//        var folderPath = Environment.getExternalStorageDirectory().absolutePath + "/path/"
//        var fileName = "comment.jpeg"
//        var imagePath = folderPath + fileName
//        var folder = File(folderPath)
//        if (!folder.isDirectory) folder.mkdirs()
//        var out = FileOutputStream(folderPath + fileName)
//        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out)
//        return imagePath }
//
//
//
//
//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        if (resultCode == Activity.RESULT_OK) {
//            when (requestCode) {
//
//                REQ_IMAGE_CAPTURE -> {
//                    imagePath?.apply {
//
//                        ctSelectImage.visibility = View.VISIBLE
//                        GlideUtil.loadImage(activity = this@AddActivity,
//                            requestOptions = RequestOptions().diskCacheStrategy(DiskCacheStrategy.NONE)
//                                .skipMemoryCache(true),
//                            image = imagePath,
//                            imageView = ivSelectImage,
//                            requestListener = object : RequestListener<Drawable> {
//                                override fun onLoadFailed(
//                                    e: GlideException?,
//                                    model: Any?,
//                                    target: Target<Drawable>?,
//                                    isFirstResource: Boolean
//                                ): Boolean {
//                                    hideLoading()
//                                    return false
//                                }
//
//                                override fun onResourceReady(
//                                    resource: Drawable?,
//                                    model: Any?,
//                                    target: Target<Drawable>?,
//                                    dataSource: DataSource?,
//                                    isFirstResource: Boolean
//                                ): Boolean {
//                                    hideLoading() return false
//                                }
//                            })
//                        checkInput()
//                    }
//                }
//            }
//        }
//    }


//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        when (requestCode) {
//            PROFILE_PICTURE -> if (data != null) {
//                getPic(data.data)
//            } else {
//                return
//            }
//        }
//    }





