package com.sjkorea.meetagain


import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import com.kakao.sdk.common.util.Utility
import com.sjkorea.meetagain.AlertFragment.AlarmFragment
import com.sjkorea.meetagain.HomeFragment.HomeFragment
import com.sjkorea.meetagain.SearchFragment.SearchFragment
import com.sjkorea.meetagain.UserFragment.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.custom_dialog.*
import kotlinx.android.synthetic.main.fregment_user.*


private var mAuth: FirebaseAuth? = null


class MainActivity : AppCompatActivity(), BottomNavigationView.OnNavigationItemSelectedListener {

    var PICK_PROFILE_FROM_ALBUM = 10
    override fun onNavigationItemSelected(item: MenuItem): Boolean {

        action_add.setOnClickListener {
            startActivity(Intent(this, AddActivity::class.java))
        }



        when (item.itemId) {
            R.id.action_home -> {
                var homeFragment = HomeFragment()

                supportFragmentManager.beginTransaction()
                    .replace(R.id.main_content, homeFragment).commit()

                return true
            }

            R.id.action_Search -> {
                var searchFragment = SearchFragment()
                supportFragmentManager.beginTransaction().replace(R.id.main_content, searchFragment)
                    .commit()

                return true
            }


            R.id.action_Notice -> {
                var alertFragment = AlarmFragment()
                supportFragmentManager.beginTransaction().replace(R.id.main_content, alertFragment)
                    .commit()

                return true
            }

            R.id.action_User -> {
                var userFragment = UserFragment()
                var bundle = Bundle()
                var uid = FirebaseAuth.getInstance().currentUser?.uid

                bundle.putString("destinationUid", uid)
                userFragment.arguments = bundle
                supportFragmentManager.beginTransaction().replace(R.id.main_content, userFragment).commit()
                return true
            }


        }
        return false

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bottomNavigationView.setOnNavigationItemSelectedListener(this)
        bottomNavigationView.selectedItemId = R.id.action_home


        val keyHash = Utility.getKeyHash(this)
        Log.d("Hash", keyHash)



        ActivityCompat.requestPermissions(
            this,
            arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE),
            1
        )

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // 앨범에서 Profile Image 사진 선택시 호출 되는 부분
        if (requestCode == PICK_PROFILE_FROM_ALBUM && resultCode == Activity.RESULT_OK) {

            var imageUri = data?.data
            var uid = FirebaseAuth.getInstance().currentUser!!.uid //파일 업로드
            var storageRef =
                FirebaseStorage.getInstance().reference.child("userProfileImages").child(
                    uid!!
                )

            //사진을 업로드 하는 부분  userProfileImages 폴더에 uid에 파일을 업로드함
            storageRef.putFile(imageUri!!)
                .continueWithTask { task: com.google.android.gms.tasks.Task<UploadTask.TaskSnapshot> ->
                    return@continueWithTask storageRef.downloadUrl
                }.addOnSuccessListener { uri ->
                var map = HashMap<String, Any>()
                map["image"] = uri.toString()
                FirebaseFirestore.getInstance().collection("profileImages").document(uid).set(map)
            }

        }

    }




//
//
//
//    bottomNavigationView.background = null
//    bottomNavigationView.menu.getItem(2).isEnabled = false
//
//
//
//    mAuth = FirebaseAuth.getInstance()
//    sign_out_and_disconnect2.text = getString(R.string.logout)
//    sign_out_and_disconnect2.setOnClickListener {
//
//        startActivity(Intent(this, LoginActivity::class.java))
//        signOut()
//
//    }


    //로그아웃
    private fun signOut() {
        FirebaseAuth.getInstance().signOut()
    }

    //회원탈퇴
    private fun revokeAccess() {
        mAuth!!.currentUser!!.delete()
    }


}