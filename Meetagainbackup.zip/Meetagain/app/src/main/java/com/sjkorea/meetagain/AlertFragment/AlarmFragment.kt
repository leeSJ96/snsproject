package com.sjkorea.meetagain.AlertFragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sjkorea.meetagain.Adapter.AlarmRecyclerViewAdapter
import com.sjkorea.meetagain.R

class AlarmFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {



        var alerview = inflater.inflate(R.layout.fregment_alarm,container,false)
        var recyclerView = alerview.findViewById<RecyclerView>(R.id.alarmfragment_recyclerview)
        recyclerView.adapter = AlarmRecyclerViewAdapter(alerview)
        recyclerView.layoutManager = LinearLayoutManager(activity)

        return alerview
    }


}