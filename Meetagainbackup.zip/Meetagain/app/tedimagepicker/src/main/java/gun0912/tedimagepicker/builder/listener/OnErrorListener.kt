package gun0912.tedimagepicker.builder.listener

interface OnErrorListener {
    fun onError(message: String)
}