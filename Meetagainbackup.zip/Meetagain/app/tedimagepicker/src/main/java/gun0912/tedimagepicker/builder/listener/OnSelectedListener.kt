package gun0912.tedimagepicker.builder.listener

import android.net.Uri

interface OnSelectedListener {
    fun onSelected(uri: Uri)
}